import numpy as np 

class ClassName(object):
    def __init__(self, *args):
        super(ClassName, self).__init__(*args))
    
    @staticmethod
    def funcname(parameter_list):
        pass